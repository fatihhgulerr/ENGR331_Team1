#pragma once

#include <stdint.h>
#include "gastrobot_packet.h"

#ifdef __cplusplus
extern "C" {
#endif

// Notification period ("BLE pulse"). Increase to extend battery life.
#ifndef GB_NOTIFY_PERIOD_MS
#define GB_NOTIFY_PERIOD_MS  (1000u)
#endif

// Call once after BLE stack is initialized and GATT is ready
void GB_BLE_InitService(void);

// Update interval at runtime (optional)
void GB_BLE_SetNotifyPeriodMs(uint32_t ms);

// Notify a packet (returns 0 on success)
int  GB_BLE_NotifyPacket(const gastrobot_packet_t* pkt);

#ifdef __cplusplus
}
#endif
