# Receiver CSV format

The receiver logger should store:
- iso_time (e.g., 2025-12-28T15:00:00.123)
- t_ms
- seq
- ph
- mv
- vbat_mv
- flags

This matches `gastrobot_packet_t`.
