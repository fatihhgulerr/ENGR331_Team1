#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void GB_App_Init(void);
void GB_App_Proc(void);

#ifdef __cplusplus
}
#endif
