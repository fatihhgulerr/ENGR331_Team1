#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// ---- Packet versioning ----
#define GB_PACKET_VERSION  (0x01u)

// ---- Flags ----
#define GB_FLAG_CAL_OK     (1u << 0)
#define GB_FLAG_BLE_OK     (1u << 1)
#define GB_FLAG_LOW_BATT   (1u << 2)

// Compact BLE payload (<= 20 bytes for legacy ATT MTU; you can expand if MTU > 23)
// Total = 1 + 4 + 2 + 2 + 2 + 1 + 2 = 14 bytes
typedef struct __attribute__((packed))
{
    uint8_t  ver;          // GB_PACKET_VERSION
    uint32_t t_ms;         // milliseconds since boot
    int16_t  ph_x100;      // pH * 100 (e.g. 725 => pH 7.25)
    int16_t  mv;           // sensor millivolts
    uint16_t vbat_mv;      // battery millivolts (optional estimate)
    uint8_t  flags;        // GB_FLAG_*
    uint16_t seq;          // packet sequence number
} gastrobot_packet_t;

#ifdef __cplusplus
}
#endif
