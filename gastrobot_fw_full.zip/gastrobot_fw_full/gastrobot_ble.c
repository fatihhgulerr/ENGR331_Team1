#include "gastrobot_ble.h"

// STM32WB BLE headers (CubeWB). These exist in a standard CubeWB BLE project.
#include "ble.h"
#include "blestack.h"
#include "svc_ctl.h"

#include <string.h>

// ---------------- UUIDs (example) ----------------
// Replace with your own UUIDs or match CubeMX-generated custom service UUIDs.
// You can also wire these to the CubeMX-generated Custom Service file.

// 128-bit base UUID: 7e57xxxx-7cda-4f2b-9b9b-xxxxxxxxxxxx (example)
// Here we use a fixed example. You can change it to your project UUIDs.

static const uint8_t GB_Service_UUID[16] =
{
    0x12,0x34,0x56,0x78, 0x9B,0x9B, 0x2B,0x4F, 0xDA,0x7C, 0x57,0x7E, 0x00,0x00,0x00,0x01
};

static const uint8_t GB_Char_UUID[16] =
{
    0x12,0x34,0x56,0x78, 0x9B,0x9B, 0x2B,0x4F, 0xDA,0x7C, 0x57,0x7E, 0x00,0x00,0x00,0x02
};

static uint16_t gb_service_handle = 0;
static uint16_t gb_char_handle    = 0;
static uint32_t gb_notify_period_ms = GB_NOTIFY_PERIOD_MS;

void GB_BLE_SetNotifyPeriodMs(uint32_t ms)
{
    if (ms < 50u) { ms = 50u; }
    gb_notify_period_ms = ms;
}

// Expose for app scheduler
uint32_t GB_BLE_GetNotifyPeriodMs(void)
{
    return gb_notify_period_ms;
}

void GB_BLE_InitService(void)
{
    tBleStatus ret;

    // Add service
    ret = aci_gatt_add_service(UUID_TYPE_128, (Service_UUID_t*)GB_Service_UUID,
                               PRIMARY_SERVICE, 7, &gb_service_handle);

    // Add characteristic (Notify)
    if (ret == BLE_STATUS_SUCCESS)
    {
        ret = aci_gatt_add_char(gb_service_handle, UUID_TYPE_128, (Char_UUID_t*)GB_Char_UUID,
                                sizeof(gastrobot_packet_t),
                                CHAR_PROP_NOTIFY,
                                ATTR_PERMISSION_NONE,
                                GATT_NOTIFY_READ_REQ_AND_WAIT_FOR_APPL_RESP,
                                0x10,
                                1,
                                &gb_char_handle);
    }

    (void)ret;
}

int GB_BLE_NotifyPacket(const gastrobot_packet_t* pkt)
{
    if ((0u == gb_service_handle) || (0u == gb_char_handle) || (NULL == pkt))
    {
        return -1;
    }

    // Send notification
    tBleStatus ret = aci_gatt_update_char_value(gb_service_handle, gb_char_handle,
                                               0, sizeof(gastrobot_packet_t), (uint8_t*)pkt);
    return (ret == BLE_STATUS_SUCCESS) ? 0 : -2;
}
