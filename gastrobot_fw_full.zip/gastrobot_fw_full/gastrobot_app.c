#include "gastrobot_app.h"
#include "gastrobot_ph.h"
#include "gastrobot_ble.h"
#include "gastrobot_packet.h"

#include "stm32wbxx_hal.h"

// Optional: use ST utilities if available in your project
// #include "stm32_seq.h"
// #include "stm32_lpm.h"

static uint32_t g_last_notify_ms = 0;
static uint16_t g_seq = 0;

static uint16_t prv_read_battery_mv(void)
{
    // If you have VBAT measurement configured, read it here.
    // Placeholder: return 0 to indicate "not measured".
    return 0;
}

void GB_App_Init(void)
{
    GB_PH_Init();

    // Must be called after BLE stack is ready. If you call GB_App_Init early,
    // then call GB_BLE_InitService later from APP_BLE_Init.
    // GB_BLE_InitService();

    g_last_notify_ms = HAL_GetTick();
    g_seq = 0;
}

void GB_App_Proc(void)
{
    uint32_t now = HAL_GetTick();

    // "BLE pulse" scheduling
    extern uint32_t GB_BLE_GetNotifyPeriodMs(void);
    uint32_t period = GB_BLE_GetNotifyPeriodMs();

    if ((now - g_last_notify_ms) >= period)
    {
        g_last_notify_ms = now;

        int16_t mv = GB_PH_Read_mV();
        int16_t ph_x100 = GB_PH_mV_to_pH_x100(mv);

        gastrobot_packet_t pkt;
        pkt.ver      = GB_PACKET_VERSION;
        pkt.t_ms     = now;
        pkt.ph_x100  = ph_x100;
        pkt.mv       = mv;
        pkt.vbat_mv  = prv_read_battery_mv();
        pkt.flags    = (GB_FLAG_CAL_OK | GB_FLAG_BLE_OK);
        pkt.seq      = g_seq++;

        (void)GB_BLE_NotifyPacket(&pkt);

        // Power saving idea:
        // Between measurements, you can enter STOP mode via UTIL_LPM if configured.
    }
}
