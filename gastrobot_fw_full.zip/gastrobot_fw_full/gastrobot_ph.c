#include "gastrobot_ph.h"

// You must provide these from your CubeMX project
// e.g., extern ADC_HandleTypeDef hadc1;
#include "stm32wbxx_hal.h"

#ifndef GB_USE_EXT_ADC_HANDLE
#define GB_USE_EXT_ADC_HANDLE 1
#endif

#if GB_USE_EXT_ADC_HANDLE
extern ADC_HandleTypeDef hadc1;
#endif

static uint8_t g_ph_inited = 0;

void GB_PH_Init(void)
{
    // ADC init is typically done by CubeMX (MX_ADC1_Init).
    // We keep this function for symmetry and potential future calibration storage.
    g_ph_inited = 1;
}

static uint16_t prv_adc_read_once(void)
{
    uint16_t adc = 0;

#if GB_USE_EXT_ADC_HANDLE
    if (HAL_OK == HAL_ADC_Start(&hadc1))
    {
        if (HAL_OK == HAL_ADC_PollForConversion(&hadc1, 10))
        {
            adc = (uint16_t)HAL_ADC_GetValue(&hadc1);
        }
        (void)HAL_ADC_Stop(&hadc1);
    }
#endif

    return adc;
}

int16_t GB_PH_Read_mV(void)
{
    uint32_t sum = 0;
    uint16_t i = 0;
    uint16_t adc = 0;
    uint32_t mv = 0;

    if (0u == g_ph_inited)
    {
        GB_PH_Init();
    }

    for (i = 0; i < GB_ADC_SAMPLES; i++)
    {
        adc = prv_adc_read_once();
        sum += (uint32_t)adc;
    }

    adc = (uint16_t)(sum / GB_ADC_SAMPLES);

    // Convert ADC counts to millivolts
    mv = ((uint32_t)adc * (uint32_t)GB_ADC_VREF_MV) / (uint32_t)GB_ADC_MAX_COUNTS;

    // If your analog front-end maps pH electrode around mid-supply, you may want to shift here.
    // Example: mv = (int32_t)mv - 1650;

    return (int16_t)mv;
}

int16_t GB_PH_mV_to_pH_x100(int16_t mv)
{
    // Simple linear model around pH7:
    // pH = 7 - (mv - offset_at_pH7)/slope
    // sign depends on your electrode / amplifier polarity.

    float f_mv = (float)mv;
    float ph = 7.0f - ((f_mv - (float)GB_PH_CAL_OFFSET_MV_AT_PH7) / (float)GB_PH_CAL_SLOPE_MV_PER_PH);

    // clamp to reasonable range
    if (ph < 0.0f) { ph = 0.0f; }
    if (ph > 14.0f) { ph = 14.0f; }

    int32_t ph_x100 = (int32_t)(ph * 100.0f);
    if (ph_x100 < -32768) { ph_x100 = -32768; }
    if (ph_x100 >  32767) { ph_x100 =  32767; }

    return (int16_t)ph_x100;
}
