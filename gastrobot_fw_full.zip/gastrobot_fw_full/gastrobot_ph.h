#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Calibration parameters (default placeholders; set from your calibration run)
// Typical Nernst slope at 25C is ~59.16 mV/pH for ideal glass electrodes.
// Your carbon/AgAgCl system may differ; use your empirical slope.
#ifndef GB_PH_CAL_SLOPE_MV_PER_PH
#define GB_PH_CAL_SLOPE_MV_PER_PH     (55.0f)   // example
#endif

#ifndef GB_PH_CAL_OFFSET_MV_AT_PH7
#define GB_PH_CAL_OFFSET_MV_AT_PH7    (0.0f)    // example: mv value at pH 7
#endif

// Number of ADC samples to average per read
#ifndef GB_ADC_SAMPLES
#define GB_ADC_SAMPLES                (32u)
#endif

// ADC reference (mV)
#ifndef GB_ADC_VREF_MV
#define GB_ADC_VREF_MV                (3300u)
#endif

// ADC resolution
#ifndef GB_ADC_MAX_COUNTS
#define GB_ADC_MAX_COUNTS             (4095u)  // 12-bit
#endif

// Public API
void    GB_PH_Init(void);
int16_t GB_PH_Read_mV(void);
int16_t GB_PH_mV_to_pH_x100(int16_t mv);

#ifdef __cplusplus
}
#endif
