# GastroBot STM32WB Firmware (Full Template)

This is a **working-grade** firmware template for STM32WB (tested structure aligned with STM32CubeWB projects).
It is designed to be dropped into a CubeMX-generated STM32WB project that uses the ST BLE stack.

## What this includes
- **pH sensing** via ADC (sample/average, convert to mV)
- **Voltage->pH conversion** with calibration parameters
- **BLE Custom Service** with Notify characteristic for streaming pH packets
- **Power-aware scheduling**: duty cycling + configurable notify period ("BLE pulse")
- **Optional debug/test hooks** (compile-time flags)

## How to integrate (CubeMX / STM32CubeWB)
1. Create a CubeMX project for your STM32WB (WB55/WB15/WB10 family as applicable).
2. Enable:
   - ADC (single-ended channel connected to your pH front-end)
   - BLE middleware (Custom service)
   - Sequencer (UTIL_SEQ) and low power manager (UTIL_LPM) are recommended.
3. Copy the files in this folder into your project under `App/` (or similar) and add them to your build.
4. Wire the hooks:
   - Call `GB_App_Init()` from `APP_BLE_Init()` (or from `MX_APPE_Init()` after BLE init).
   - Call `GB_App_Proc()` regularly from main loop (or schedule via sequencer).
   - In your Custom ST service file, call `GB_BLE_InitService()` once BLE stack is ready.

## Key tuning knobs
- `GB_NOTIFY_PERIOD_MS`: BLE notify period (lower = more frequent). **Increase** to save battery.
- `GB_ADC_SAMPLES`: number of ADC samples per reading (higher = less noise, more energy).
- `GB_PH_CAL_SLOPE_MV_PER_PH` and `GB_PH_CAL_OFFSET_MV_AT_PH7`: calibration.

## Data packet format (little-endian)
`gastrobot_packet_t` (see `gastrobot_packet.h`)

## ST-LINK V3 debugging
- Set breakpoints in `GB_PH_Read_mV()` and `GB_BLE_NotifyPacket()`.
- Watch variables: `mv`, `ph_x100`, `notify_period_ms`.

> Note: You may need to adapt ADC channel configuration and BLE UUID registration to match your CubeMX-generated files.
